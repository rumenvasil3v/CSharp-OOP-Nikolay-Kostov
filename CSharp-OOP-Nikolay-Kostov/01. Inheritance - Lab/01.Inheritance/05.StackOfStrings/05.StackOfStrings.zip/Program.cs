﻿namespace CustomStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            StackOfStrings strings = new StackOfStrings();
            Stack<string> stack = new Stack<string>();
            stack.Push("Pesho");
            stack.Push("Pavel");
            stack.Push("Koko");

            strings.AddRange(stack);
            strings.Push("Smt");
            strings.Push("Wyd");

            foreach (string s in strings)
            {
                Console.WriteLine(s);
            }

            Console.WriteLine(strings.IsEmpty());
        }
    }
}