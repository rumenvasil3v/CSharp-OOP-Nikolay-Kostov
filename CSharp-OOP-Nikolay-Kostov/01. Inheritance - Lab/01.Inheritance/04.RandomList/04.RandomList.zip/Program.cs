﻿namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var randomList = new RandomList
            {
                "Pesho",
                "Gosho",
                "Koko",
                "Pavel"
            };

            string element = randomList.RandomString();
            Console.WriteLine(element);
           
        }
    }
}