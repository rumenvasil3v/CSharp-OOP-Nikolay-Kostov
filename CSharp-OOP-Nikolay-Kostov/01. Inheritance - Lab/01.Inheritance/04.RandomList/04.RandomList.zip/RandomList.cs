﻿namespace CustomRandomList
{
    public class RandomList : List<string>
    {
        private Random randomElement;

        public RandomList()
        {
            randomElement = new Random();
        }

        public string RandomString()
        {
            int randomIndex = randomElement.Next(0, this.Count);
            string element = this[randomIndex];

            this.RemoveAt(randomIndex);

            return element;
        }
    }
}