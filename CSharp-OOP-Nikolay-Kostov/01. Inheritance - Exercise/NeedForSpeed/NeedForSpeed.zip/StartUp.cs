﻿using System;
using NeedForSpeed.Vehicles;

namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var car = new Car(200, 100);
            car.Drive(20);
            Console.WriteLine(car.Fuel);
        }
    }
}