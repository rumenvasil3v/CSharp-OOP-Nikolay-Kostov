﻿namespace Zoo.Animals.ReptileChildren
{
    public class Lizard : Reptile
    {
        public Lizard(string name) : base(name)
        {
        }
    }
}