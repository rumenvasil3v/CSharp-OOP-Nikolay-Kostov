﻿namespace Zoo.Animals.MammalChildren
{
    public class Bear : Mammal
    {
        public Bear(string name) : base(name)
        {
        }
    }
}